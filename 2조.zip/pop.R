install.packages("foreign")

library(foreign)
library(dplyr)
library(ggplot2)
library(readxl)

install.packages("ggiraphExtra")
library(ggiraphExtra)


population <-read.csv("c:/workspace/population5.csv")

str(population)
dim(population)
head(population)
View(population)
summary(population)

population <- rename( population,
                      Age5_Age64 = "총인구수",
                      Age5_Age9 = "X5.9age",
                      Age10_Age14 = "X10.14age",
                      Age15_Age19 = "X15.19age",
                      Age20_Age24 = "X20.24age",
                      Age25_Age29 = "X25.29age",
                      Age30_Age34 = "X30.34age",
                      Age35_Age39 = "X35.39age",
                      Age40_Age44 = "X40.44age",
                      Age45_Age49 = "X45.49age",
                      Age50_Age54 = "X50.54age",
                      Age55_Age59 = "X55.59age",
                      Age60_Age64 = "X60.64age",
                      시군구명 = "행정구역")
View(population)

class(population$Age5_Age64)
table(population$Age5_Age64)
summary(population$Age5_Age64)

population$시군구명 <- ifelse(population$시군구명 == "대전광역시 동구", "동구",
                         ifelse(population$시군구명 %in% "대전광역시 중구", "중구",
                                ifelse(population$시군구명 %in% "대전광역시 서구", "서구",
                                       ifelse(population$시군구명 %in% "대전광역시 유성구", "유성구","대덕구"))))
population$시군구명

View(population)








table(is.na(population$Age5_Age64))

ggplot(data = population, aes(x = 시군구명, y = Age5_Age64)) + geom_col()





lib<-read.csv(file = "C:/Workspace/library.csv")
View(lib)
lib2<-select(lib,lib$시군구명)
View(lib2)
lib3<- mutate(lib2,num=1)
View(lib3)

lib4<-lib3 %>% 
  group_by(시군구명) %>% 
  summarise(합계=sum(num))

ggplot(lib4,aes(x=시군구명,y=합계))+geom_col()

lib4
View(lib4)




fi<- left_join(population,lib4,by="시군구명")

View(fi)


fi2<- mutate(fi, age_lib = fi$Age5_Age64 / fi$합계)
View(fi2)


ggplot(data = fi2, aes(x = 시군구명, y = age_lib)) + geom_col()


row <- read.csv("C:/Users/CPB06GameN/Desktop/dd2017.csv", header=TRUE)
View(row)

row1 <- select(row, c("시도명", "시군구명", "소재지", "공시지가" ))

View(row1)

row2 <- rename(row1, "si" = "시도명",
               "gu" = "시군구명",
               "dong" = "소재지",
               "p" = "공시지가")

View(row2)

row3 <- filter(row2, row2$si == "대전광역시") 

View(row3)

row4 <- row3 %>%
  group_by(si, gu, dong) %>%
  summarise(n=mean(p))

View(row4)             # 공시지가는 면적당 적정 가격

table(row4$dong)


row5 <- row4 %>%
  mutate(dong1 = strsplit(dong," "), dong2 = " " )

row5$dong1 <- as.data.frame( row5$dong1 )
str( row5 )
head( row5 )

# 동명만 추출하는 Code Block ###########
max_length <- length( row5$dong1 )
i <- 1
while ( i <= max_length ) {
  row5$dong2[i] <- row5$dong1[[i]][2]
  
  i <- i + 1
}
row5 <- row5[-5]
########################################

str(row4)

row4$dong <- as.character(row4$dong)

str(row4)

View(row5)

str(row5)

row5$dong1[[1]][2]

ed <- strsplit(row4$dong," ")

View(ed)

ed[[1]][2]

row6 <- row5 %>%
  group_by(si, gu, dong2) %>%
  summarise(n=mean(n))

View(row6)    # 동별 공시지가

row7 <- arrange(row6, row6$n)

View(row7)

ggplot(data = row7, aes(x = dong2, y = n)) + geom_col()

row8 <- row6 %>%
  filter(gu == "서구")

View(row8)

seogu <- arrange(row8, row8$n)

View(seogu)

mean(seogu$n)
ggplot(data = seogu, aes(x=dong2, y=n)) + geom_col(fill = "dark green")






school <- read_excel("C:/Workspace/R/project/school.xlsx")
schoolbox <- school
View(schoolbox)

table(schoolbox $지역)
qplot(schoolbox $지역) + xlab("지역단위") + ylab("학교수")

school_서구 <- schoolbox %>% filter(지역 == "서구")
qplot(school_서구$주소) + xlab("서구지역") + ylab("학교수")
table(school_서구$주소)
dim(school_서구)

school_유성구 <- schoolbox %>% filter(지역 == "유성구")
qplot(school_유성구$주소) + xlab("유성구지역") + ylab("학교수")
table(school_유성구$주소)
dim(school_유성구)

school_중구 <- schoolbox %>% filter(지역 == "중구")
qplot(school_중구$주소) + xlab("중구지역") + ylab("학교수")
table(school_중구$주소)
dim(school_중구)

